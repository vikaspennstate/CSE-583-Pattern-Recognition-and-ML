You are given starter code which contains the following: 
generateData.m
 -Code to generate noisy sample points
 -Code to save data
curveFit.m
 -Code to plot points and curves

Implement your own code in curveFit.m.


Run generateData.m will create a file named data.mat in your current working directory. Then run curveFit.m. A plot should appear, which looks like the sampleplot.png under the sample_output sub directory. 


